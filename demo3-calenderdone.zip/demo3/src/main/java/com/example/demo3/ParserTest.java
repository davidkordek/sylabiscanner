package com.example.demo3;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ParserTest {

    @Test
    void showEntireCalendar() {
    }

    @Test
    void parseFile() {
    }

    @Test
    void insertNewEvent() {
    }

    @Test
    void parseEventObject() {
    }

    @Test
    void printSingleEventObject() {
    }

    @Test
    void isEventMatch() {
        Parser parser = new Parser();
       // assertEquals();
    }

    @Test
    void readJSON() {
    }

    @Test
    void removeEvent() {
    }
}